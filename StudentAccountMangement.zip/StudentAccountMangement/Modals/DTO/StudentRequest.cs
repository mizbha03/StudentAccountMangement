﻿namespace StudentAccountMangement.Modals.DTO
{
    public class StudentRequest
    {
        public int User_id { get; set; }
        public string Description { get; set; }
        public decimal Amount { get; set; }
    }
}
