﻿namespace StudentAccountMangement.Modals.DTO
{
    
    public class StudentStatement
    {
            public int T_id { get; set; }
            public string Type { get; set; }
            public decimal Amount { get; set; }
            public string Mode { get; set; }
            public DateTime TDate { get; set; }
            public string AdminName { get; set; }

    }

}
