﻿namespace StudentAccountMangement.Modals.DTO
{

    public class AdminStatement
    {
        public int T_id { get; set; }
        public string Type { get; set; }
        public decimal Amount { get; set; }
        public string Mode { get; set; }
        public DateTime TDate { get; set; }
    }


}
