﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentAccountMangement.Helper;
using StudentAccountMangement.Modals;
using StudentAccountMangement.Modals.DTO;
using System.ComponentModel.DataAnnotations;

namespace StudentAccountMangement.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly SAMContext _context;

        public UserController(SAMContext context)
        {
            _context = context;
        }

        [HttpGet("GetUser/{User_id}")]
        public async Task<ActionResult<User>> GetUser(int User_id)
        {
            try
            {
                User user = await _context.User_tb.FirstOrDefaultAsync(x => x.User_id == User_id);

                if (user == null)
                {
                    return NotFound();
                }
                else
                {
                    user.Password = PasswordHelper.Decrypt(user.Password);

                    return user;
                }
            }
          
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("GetAllUser")]
        public async Task<ActionResult<IEnumerable<User>>> GetAllCourses()
        {
            List<User> user = await _context.User_tb.ToListAsync();
            return user;
        }
        
        [HttpPost("Add")]
        public async Task<IActionResult> Add(User user)
        {
            try
            {
                if (!string.IsNullOrEmpty(user.ProfileImage) && !string.IsNullOrEmpty(user.ImagePath))
                {
                    user.ImagePath = ImagePathHelper.SaveFile(user.ProfileImage, user.ImagePath);
                }

                user.Password = PasswordHelper.Encrypt(user.Password);
                user.ProfileImage = "";

                _context.User_tb.Add(user); 
                await _context.SaveChangesAsync();

                return Ok("User Saved!");
            }
            
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        [HttpPut("Update")]
        public async Task<ActionResult<User>> Update(User user)
        {
            try
            {
                User ExistUser = await _context.User_tb.FirstOrDefaultAsync(x => x.User_id == user.User_id);

                if (ExistUser != null)
                {
                    ExistUser.Name = user.Name;
                    if (!string.IsNullOrEmpty(user.ProfileImage))
                    {
                        ExistUser.ImagePath = ImagePathHelper.SaveFile(user.ProfileImage, ".png");
                    }
                    ExistUser.UserName = user.UserName;
                    ExistUser.Password = PasswordHelper.Encrypt(user.Password);
                    ExistUser.Role = user.Role;
                    //ExistUser.Status = user.Status;

                    _context.User_tb.Update(ExistUser);
                    await _context.SaveChangesAsync();

                    return Ok(ExistUser);
                }
                else
                {
                    return NotFound();
                }
            }
            
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }

        }

        [HttpDelete("Delete/{User_id}")]
        public async Task<IActionResult> DeleteCourse(int User_id)
        {
            User ExistUser = await _context.User_tb.FirstOrDefaultAsync(x => x.User_id == User_id);
            if (ExistUser == null)
            {
                return NotFound();
            }

            _context.User_tb.Remove(ExistUser);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        //#region Private functions

        //private string SaveFile(string base64, string extension)
        //{
        //    string filename = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss-FF") + extension;
        //    string FolderPath = "D:\\ProfileImage\\" + filename;
        //    byte[] byteoffile = Convert.FromBase64String(base64);
        //    System.IO.File.WriteAllBytes(FolderPath, byteoffile);

        //    return FolderPath;
        //}

        //# endregion
       
        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            try
            {
                var user = await _context.User_tb
           .FirstOrDefaultAsync(u => u.UserName.ToLower() == request.Username.ToLower());

                
                if (user == null)
                {
                    return Unauthorized("Username not found.");
                }

                
                var encryptedInputPassword = PasswordHelper.Encrypt(request.Password);

                if (user.Password != encryptedInputPassword)
                {
                    return Unauthorized("Incorrect password.");
                }


                var loginHistory = new LoginHistory
                {
                    UserId = user.User_id,
                    LoginTime = DateTime.UtcNow,
                    Role = user.Role.ToString()
                     
                };

                _context.LoginHistory_tb.Add(loginHistory);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    message = "Login successful",
                    user.User_id,
                    user.Name,
                    user.UserName,
                    Role = user.Role.ToString()
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }
}

