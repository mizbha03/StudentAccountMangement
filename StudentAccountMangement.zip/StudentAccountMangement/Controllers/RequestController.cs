﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentAccountMangement.Modals;
using StudentAccountMangement.Modals.DTO;

namespace StudentAccountMangement.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class RequestController : ControllerBase
    {
        private readonly SAMContext _context;

        public RequestController(SAMContext context)
        {
            _context = context;
        }

        [HttpPost("SubmitRequest")]
        public async Task<IActionResult> SubmitRequest(StudentRequest studentRequest)
        {
            Request newRequest = new Request
            {
                User_id = studentRequest.User_id,
                Description = studentRequest.Description,
                Amount = studentRequest.Amount,
                Request_date = DateTime.Now,
                Proceeded_by = null,
                Proceeded_date = null
            };

            _context.Request_tb.Add(newRequest);
            await _context.SaveChangesAsync();

            return Ok("Request submitted successfully.");
        }

        [HttpGet("GetAllPendingRequests")]
        public async Task<ActionResult<IEnumerable<Request>>> GetAllPendingRequests()
        {
            var requests = await _context.Request_tb.Where(r => r.Proceeded_by == null).ToListAsync();

            return Ok(requests);
        }

        [HttpPost("ApproveRequest/{requestId}/{adminId}")]
        public async Task<IActionResult> ApproveRequest(int requestId, int adminId)
        {
            try
            {
                Request request = await _context.Request_tb.FindAsync(requestId);
                if (request == null) return NotFound();

                Account account = await _context.Account_tb.FirstOrDefaultAsync(a => a.User_id == request.User_id);
                if (account == null)
                {
                    account = new Account
                    {
                        User_id = request.User_id,
                        Balance = 0
                    };
                    _context.Account_tb.Add(account);
                    await _context.SaveChangesAsync();
                }


                request.Proceeded_by = adminId;
                request.Proceeded_date = DateTime.Now;
                _context.Request_tb.Update(request);


                account.Balance -= request.Amount;
                _context.Account_tb.Update(account);


                Statement statement = new Statement
                {
                    User_id = request.User_id,
                    Type = "withdraw",
                    Amount = request.Amount,
                    Mode = "Request",
                    Status = "approved",
                    Admin_id = adminId,
                    TDate = DateTime.Now
                };
                _context.Statement_tb.Add(statement);

                await _context.SaveChangesAsync();
                return Ok("Request approved and balance updated.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
            

    }

}
