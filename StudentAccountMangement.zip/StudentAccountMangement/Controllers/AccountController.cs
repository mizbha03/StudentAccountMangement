﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentAccountMangement.Modals;

namespace StudentAccountMangement.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly SAMContext _context;

        public AccountController(SAMContext context)
        {
            _context = context;
        }

        [HttpGet("GetBalancebyId/{Acc_id}")]
        public async Task<ActionResult<Account>> GetBalance(int Acc_id)
        {
            try
            {
                Account account = await _context.Account_tb.FirstOrDefaultAsync(x => x.Acc_id == Acc_id);

                if (account == null)
                {
                    return NotFound();
                }
                else
                {
                    return account;
                }
            }
            
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("GetAllBalance")]
        public async Task<ActionResult<IEnumerable<Account>>> GetAllStatements()
        {
            List<Account> account = await _context.Account_tb.ToListAsync();
            return account;
        }
    }
}
