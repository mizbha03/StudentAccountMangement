﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentAccountMangement.Helper;
using StudentAccountMangement.Modals;

namespace StudentAccountMangement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase  
    {
        private readonly SAMContext _context;
             
        public AuthController(SAMContext context)
        {
            _context = context;
        }

        [HttpPost("login")]
        public ActionResult Login([FromBody] Login login)
        {
            var user = _context.Login_tb.FirstOrDefault(u => u.Username == login.Username);

            if (user == null)
            {
                return Unauthorized("Invalid credentials");
            }
            if (user.Password != login.Password)
            {
                return Unauthorized("Invalid credentials");
            }
            string token = AuthHelper.GenerateJwtToken(login.Username);

            return Ok(new { Token = token });
        }
    }
}
 