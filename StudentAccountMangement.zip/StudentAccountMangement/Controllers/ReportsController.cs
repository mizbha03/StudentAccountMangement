﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentAccountMangement.Modals.DTO;

namespace StudentAccountMangement.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ReportsController : ControllerBase
    {
        private readonly SAMContext _context;

        public ReportsController(SAMContext context)
        {
            _context = context;
        }

        [HttpGet("GetStudentStatements")]
        public async Task<ActionResult<IEnumerable<StudentStatement>>> GetStudentStatements()
        {
            var result = await _context.StudentStatements.FromSqlRaw("EXEC GetStudentStatements").ToListAsync();

            return Ok(result);
        }

        [HttpGet("GetStudentStatementsById/{userId}")]
        public async Task<ActionResult<IEnumerable<StudentStatementById>>> GetStudentStatementsById(int userId)
        {
            var result = await _context.StudentStatementByIds.FromSqlRaw("EXEC GetStudentStatementById @UserId = {0}", userId).ToListAsync();

            return Ok(result);
        }


        [HttpGet("GetAdminStatements")]
        public async Task<ActionResult<IEnumerable<AdminStatement>>> GetAdminStatements()
        {
            var result = await _context.AdminStatements.FromSqlRaw("EXEC GetAdminStatements").ToListAsync();

            return Ok(result);
        }

    }
}
