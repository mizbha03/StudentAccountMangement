﻿namespace StudentAccountMangement.Enums
{
    public enum UserRole
    {
        admin = 1,
        student = 2
    }
}