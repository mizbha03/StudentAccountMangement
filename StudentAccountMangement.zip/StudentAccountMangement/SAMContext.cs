﻿using Microsoft.EntityFrameworkCore;
using StudentAccountMangement.Modals;
using StudentAccountMangement.Modals.DTO;

namespace StudentAccountMangement
{
    public class SAMContext : DbContext
    {
        
            public SAMContext(DbContextOptions<SAMContext> options) : base(options)
            {
            }

            public DbSet<User> User_tb { get; set; }
            public DbSet<Account> Account_tb { get; set; }
            public DbSet<Statement> Statement_tb { get; set; }
            public DbSet<Request> Request_tb { get; set; }
            public DbSet<StudentStatement> StudentStatements { get; set; }
            public DbSet<AdminStatement> AdminStatements { get; set; }
            public DbSet<StudentStatementById> StudentStatementByIds { get; set; }
            public DbSet<Login> Login_tb { get; set; }
            public DbSet<LoginHistory> LoginHistory_tb { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>().Property(e => e.Role).HasConversion<string>();
            modelBuilder.Entity<StudentStatement>().HasNoKey();
            modelBuilder.Entity<AdminStatement>().HasNoKey();
            modelBuilder.Entity<StudentStatementById>().HasNoKey();
        }
    }
}
